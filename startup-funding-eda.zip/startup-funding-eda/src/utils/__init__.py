"""Módulos auxiliares del proyecto: limpieza, variables, estadística y gráficos."""
