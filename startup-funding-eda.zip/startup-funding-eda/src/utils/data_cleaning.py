"""
data_cleaning.py
----------------
Funciones de carga y limpieza de los datos brutos de Crunchbase.

Fuente: export abierto de Crunchbase (2015) publicado en
https://github.com/notpeter/crunchbase-data (ficheros companies.csv y rounds.csv).
"""

from pathlib import Path

import numpy as np
import pandas as pd

# Fecha de corte del dataset: la ronda más reciente registrada es de finales de 2015.
FECHA_CORTE = pd.Timestamp("2015-12-31")

# Columnas que no aportan nada al análisis (URLs, códigos redundantes)
COLS_INUTILES_COMPANIES = ["homepage_url", "state_code", "region"]
COLS_INUTILES_ROUNDS = [
    "company_name", "company_category_list", "company_country_code",
    "company_state_code", "company_region", "company_city",
]


def cargar_datos_brutos(data_dir):
    """Carga los dos CSV brutos (comprimidos .gz) y los devuelve como DataFrames.

    Parameters
    ----------
    data_dir : str | Path
        Carpeta que contiene `raw/companies.csv.gz` y `raw/rounds.csv.gz`.

    Returns
    -------
    (companies, rounds) : tuple[pd.DataFrame, pd.DataFrame]
    """
    data_dir = Path(data_dir)
    companies = pd.read_csv(data_dir / "raw" / "companies.csv.gz")
    rounds = pd.read_csv(data_dir / "raw" / "rounds.csv.gz")
    return companies, rounds


def informe_calidad(df):
    """Resumen de calidad por columna: tipo, nulos, % nulos y nº de valores únicos."""
    return pd.DataFrame({
        "tipo": df.dtypes.astype(str),
        "nulos": df.isna().sum(),
        "pct_nulos": (df.isna().mean() * 100).round(2),
        "valores_unicos": df.nunique(),
    }).sort_values("pct_nulos", ascending=False)


def limpiar_companies(df):
    """Limpia la tabla de empresas.

    Pasos:
      1. Elimina columnas inútiles y duplicados por `permalink`.
      2. Convierte `funding_total_usd` a numérico ('-' significa "sin dato").
      3. Convierte las fechas y descarta años imposibles (anteriores a 1900 o
         posteriores a la fecha de corte).
      4. Rellena categoría y país desconocidos y extrae la categoría principal
         (la primera de la lista separada por '|').
      5. Elimina las filas sin nombre (1 registro).
    """
    df = df.copy()
    df = df.drop(columns=COLS_INUTILES_COMPANIES, errors="ignore")
    df = df.drop_duplicates(subset="permalink")
    df = df.dropna(subset=["name"])

    # 2. Financiación total: '-' -> NaN
    df["funding_total_usd"] = pd.to_numeric(
        df["funding_total_usd"].replace("-", np.nan), errors="coerce"
    )

    # 3. Fechas
    for col in ["founded_at", "first_funding_at", "last_funding_at"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
        fuera_de_rango = (df[col].dt.year < 1900) | (df[col] > FECHA_CORTE)
        df.loc[fuera_de_rango, col] = pd.NaT

    # Si la primera ronda es posterior a la última, el dato es incoherente
    incoherente = df["first_funding_at"] > df["last_funding_at"]
    df.loc[incoherente, ["first_funding_at", "last_funding_at"]] = pd.NaT

    # 4. Categoría y país
    df["category_list"] = df["category_list"].fillna("Unknown")
    df["main_category"] = df["category_list"].str.split("|").str[0].str.strip()
    df["country_code"] = df["country_code"].fillna("Unknown")
    df["city"] = df["city"].fillna("Unknown")

    return df.reset_index(drop=True)


def limpiar_rounds(df):
    """Limpia la tabla de rondas de financiación.

    - Elimina columnas que ya están en `companies` y duplicados.
    - Convierte la fecha y descarta fechas imposibles.
    - Mantiene las rondas sin importe (`raised_amount_usd` nulo): sabemos que
      la ronda existió aunque no se conozca la cantidad.
    """
    df = df.copy()
    df = df.drop(columns=COLS_INUTILES_ROUNDS, errors="ignore")
    df = df.drop_duplicates(subset="funding_round_permalink")
    df["funded_at"] = pd.to_datetime(df["funded_at"], errors="coerce")
    df.loc[(df["funded_at"].dt.year < 1900) | (df["funded_at"] > FECHA_CORTE), "funded_at"] = pd.NaT
    df.loc[df["raised_amount_usd"] < 0, "raised_amount_usd"] = np.nan
    return df.reset_index(drop=True)
