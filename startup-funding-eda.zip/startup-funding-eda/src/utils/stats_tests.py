"""
stats_tests.py
--------------
Medidas estadísticas y contrastes de hipótesis usados en la memoria.

Todos los contrastes usan un nivel de significación alfa = 0.05.
"""

import numpy as np
import pandas as pd
from scipy import stats

ALFA = 0.05


def intervalo_wilson(exitos, n, z=1.96):
    """Intervalo de confianza al 95 % (Wilson) para una proporción."""
    if n == 0:
        return np.nan, np.nan
    p = exitos / n
    denom = 1 + z**2 / n
    centro = (p + z**2 / (2 * n)) / denom
    margen = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / denom
    return centro - margen, centro + margen


def tasas_por_grupo(df, grupo, indicadores=("exito", "cerrada")):
    """Tasa (%) de cada indicador binario por grupo, con IC 95 % y tamaño n."""
    filas = []
    for nombre, sub in df.groupby(grupo, observed=True):
        fila = {grupo: nombre, "n": len(sub)}
        for ind in indicadores:
            k = sub[ind].sum()
            lo, hi = intervalo_wilson(k, len(sub))
            fila[f"tasa_{ind}"] = 100 * k / len(sub)
            fila[f"{ind}_ic_inf"] = 100 * lo
            fila[f"{ind}_ic_sup"] = 100 * hi
        filas.append(fila)
    return pd.DataFrame(filas).round(2)


def chi_cuadrado(df, col_a, col_b):
    """Test chi-cuadrado de independencia + V de Cramér (tamaño del efecto).

    V de Cramér: 0 = ninguna asociación, 1 = asociación perfecta.
    Orientativo: <0.1 despreciable, 0.1–0.3 débil, 0.3–0.5 moderada, >0.5 fuerte.
    """
    tabla = pd.crosstab(df[col_a], df[col_b])
    chi2, p, gl, _ = stats.chi2_contingency(tabla)
    n = tabla.values.sum()
    v = np.sqrt(chi2 / (n * (min(tabla.shape) - 1)))
    return {
        "chi2": round(chi2, 2), "p_valor": p, "grados_libertad": gl,
        "v_cramer": round(v, 3), "n": int(n), "significativo": p < ALFA,
    }


def mann_whitney(a, b, nombre_a="A", nombre_b="B"):
    """Test U de Mann-Whitney (compara dos grupos sin suponer normalidad).

    Devuelve las medianas y la correlación biserial de rangos como tamaño del
    efecto (r > 0 => el grupo A tiende a tener valores mayores que B).
    """
    a, b = pd.Series(a).dropna(), pd.Series(b).dropna()
    u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    r = 2 * u / (len(a) * len(b)) - 1
    return {
        f"mediana_{nombre_a}": a.median(), f"mediana_{nombre_b}": b.median(),
        "U": u, "p_valor": p, "efecto_r": round(r, 3), "significativo": p < ALFA,
    }


def kruskal_por_grupo(df, valor, grupo):
    """Test de Kruskal-Wallis: ¿difiere la distribución de `valor` entre grupos?"""
    muestras = [s[valor].dropna() for _, s in df.groupby(grupo, observed=True)]
    h, p = stats.kruskal(*muestras)
    return {"H": round(h, 2), "p_valor": p, "significativo": p < ALFA}


def spearman(x, y):
    """Correlación de Spearman (relación monótona, robusta a valores extremos)."""
    datos = pd.concat([pd.Series(x), pd.Series(y)], axis=1).dropna()
    rho, p = stats.spearmanr(datos.iloc[:, 0], datos.iloc[:, 1])
    return {"rho": round(rho, 3), "p_valor": p, "n": len(datos), "significativo": p < ALFA}


def test_normalidad(x, muestra=5000, semilla=42):
    """Test de normalidad de D'Agostino sobre una muestra (n grande => siempre rechaza)."""
    x = pd.Series(x).dropna()
    if len(x) > muestra:
        x = x.sample(muestra, random_state=semilla)
    k2, p = stats.normaltest(x)
    return {"estadistico": round(k2, 2), "p_valor": p, "es_normal": p >= ALFA}


def resumen_estadistico(serie):
    """Medidas de tendencia central, dispersión y forma de una variable numérica."""
    s = pd.Series(serie).dropna()
    return pd.Series({
        "n": len(s),
        "media": s.mean(),
        "mediana": s.median(),
        "moda": s.mode().iloc[0] if not s.mode().empty else np.nan,
        "desv_tipica": s.std(),
        "min": s.min(),
        "Q1": s.quantile(0.25),
        "Q3": s.quantile(0.75),
        "IQR": s.quantile(0.75) - s.quantile(0.25),
        "max": s.max(),
        "asimetria": s.skew(),
        "curtosis": s.kurt(),
    })


def formatear_p(p):
    """Formatea un p-valor para mostrarlo en texto."""
    return "< 0.001" if p < 0.001 else f"{p:.3f}"
