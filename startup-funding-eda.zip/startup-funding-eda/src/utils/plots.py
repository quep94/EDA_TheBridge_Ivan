"""
plots.py
--------
Funciones de visualización con un estilo común para todo el proyecto.

Código de color (siempre el mismo en todos los gráficos):
  - Éxito (adquirida / IPO) -> azul
  - Cerrada                 -> naranja
  - Operando                -> gris neutro
"""

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
import seaborn as sns

COLORES = {"Éxito": "#2a78d6", "Cerrada": "#eb6834", "Operando": "#b5b3ac"}
SECUENCIAL = "Blues"
TEXTO = "#0b0b0b"
TEXTO_2 = "#52514e"
REJILLA = "#e4e3df"

IMG_DIR = Path(__file__).resolve().parents[1] / "img"


def configurar_estilo():
    """Estilo global de matplotlib: limpio, rejilla discreta, sin bordes superiores."""
    sns.set_theme(style="whitegrid")
    plt.rcParams.update({
        "figure.figsize": (10, 5),
        "figure.dpi": 110,
        "savefig.dpi": 150,
        "savefig.bbox": "tight",
        "axes.edgecolor": REJILLA,
        "axes.labelcolor": TEXTO_2,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.titlecolor": TEXTO,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.color": REJILLA,
        "grid.linewidth": 0.8,
        "xtick.color": TEXTO_2,
        "ytick.color": TEXTO_2,
        "legend.frameon": False,
        "font.size": 11,
    })


def guardar(fig, nombre):
    """Guarda la figura en src/img/<nombre>.png."""
    IMG_DIR.mkdir(exist_ok=True)
    fig.savefig(IMG_DIR / f"{nombre}.png")


def _formato_dolares(x, _pos=None):
    if x >= 1e9:
        return f"{x/1e9:g} B$"
    if x >= 1e6:
        return f"{x/1e6:g} M$"
    if x >= 1e3:
        return f"{x/1e3:g} k$"
    return f"{x:g} $"


def grafico_resultados(df):
    """Barras horizontales: cuántas startups hay en cada resultado."""
    conteo = df["resultado"].value_counts().reindex(["Operando", "Éxito", "Cerrada"])
    pct = 100 * conteo / conteo.sum()
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.barh(conteo.index, conteo.values,
            color=[COLORES[k] for k in conteo.index], height=0.6)
    for i, (n, p) in enumerate(zip(conteo.values, pct.values)):
        ax.text(n + conteo.max() * 0.01, i, f"{n:,.0f}  ({p:.1f} %)".replace(",", "."),
                va="center", color=TEXTO)
    ax.invert_yaxis()
    ax.set_xlim(0, conteo.max() * 1.25)
    ax.set_xlabel("Número de startups")
    ax.set_title("¿Qué ha pasado con las startups del dataset?")
    ax.grid(axis="y", visible=False)
    return fig


def grafico_distribucion_financiacion(df):
    """Histograma de la financiación total en escala logarítmica."""
    datos = df["funding_total_usd"].dropna()
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))

    axes[0].hist(datos, bins=60, color=COLORES["Éxito"])
    axes[0].set_title("Escala normal: casi todo se amontona a la izquierda")
    axes[0].xaxis.set_major_formatter(mticker.FuncFormatter(_formato_dolares))
    axes[0].set_xlabel("Financiación total")
    axes[0].set_ylabel("Nº de startups")

    bins = np.logspace(0, np.log10(datos.max()), 60)
    axes[1].hist(datos, bins=bins, color=COLORES["Éxito"])
    axes[1].set_xscale("log")
    axes[1].axvline(datos.median(), color=TEXTO, ls="--", lw=1.5)
    axes[1].text(datos.median() * 1.3, axes[1].get_ylim()[1] * 0.92,
                 f"Mediana: {_formato_dolares(datos.median())}", color=TEXTO)
    axes[1].set_title("Escala logarítmica: se ve la forma real")
    axes[1].xaxis.set_major_formatter(mticker.FuncFormatter(_formato_dolares))
    axes[1].set_xlabel("Financiación total (escala log)")
    fig.tight_layout()
    return fig


def grafico_boxplot_por_resultado(df):
    """Boxplot de la financiación (log) para cada resultado."""
    datos = df.dropna(subset=["funding_total_usd"])
    fig, ax = plt.subplots(figsize=(10, 4.5))
    sns.boxplot(data=datos, x="funding_total_usd", y="resultado",
                order=["Éxito", "Operando", "Cerrada"], palette=COLORES,
                hue="resultado", legend=False, log_scale=True, showfliers=False,
                width=0.55, ax=ax)
    medianas = datos.groupby("resultado", observed=True)["funding_total_usd"].median()
    for i, k in enumerate(["Éxito", "Operando", "Cerrada"]):
        ax.text(medianas[k], i - 0.32, f"mediana {medianas[k] / 1e6:.1f} M$".replace(".", ","),
                ha="center", color=TEXTO, fontsize=10)
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(_formato_dolares))
    ax.set_xlabel("Financiación total (escala log, sin valores extremos)")
    ax.set_ylabel("")
    ax.set_title("Las startups que triunfan reciben mucha más financiación")
    return fig


def grafico_tasas(tabla, grupo, titulo, xlabel=""):
    """Dos paneles: tasa de éxito y tasa de cierre por grupo, con IC 95 %.

    Se usan dos paneles separados (y no un doble eje) para no mezclar escalas.
    """
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), sharex=True)
    x = np.arange(len(tabla))
    for ax, ind, nombre, color in [
        (axes[0], "exito", "Tasa de éxito (adquirida / IPO)", COLORES["Éxito"]),
        (axes[1], "cerrada", "Tasa de cierre", COLORES["Cerrada"]),
    ]:
        tasa = tabla[f"tasa_{ind}"].values
        err = np.vstack([tasa - tabla[f"{ind}_ic_inf"], tabla[f"{ind}_ic_sup"] - tasa])
        ax.bar(x, tasa, color=color, width=0.65)
        ax.errorbar(x, tasa, yerr=err, fmt="none", ecolor=TEXTO_2, capsize=4, lw=1)
        techo = tabla[f"{ind}_ic_sup"].values
        for xi, t, top in zip(x, tasa, techo):
            ax.text(xi, top + max(techo) * 0.02, f"{t:.1f} %", ha="center", va="bottom", color=TEXTO)
        ax.set_xticks(x, tabla[grupo].astype(str))
        ax.set_title(nombre)
        ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
        ax.set_xlabel(xlabel)
        ax.grid(axis="x", visible=False)
        ax.set_ylim(0, max(tabla[f"{ind}_ic_sup"]) * 1.18)
    fig.suptitle(titulo, fontsize=15, fontweight="bold", color=TEXTO, y=1.03)
    fig.tight_layout()
    return fig


def grafico_resultado_apilado(df, grupo, titulo, xlabel=""):
    """Barras 100 % apiladas: composición de resultados dentro de cada grupo."""
    tabla = pd.crosstab(df[grupo], df["resultado"], normalize="index") * 100
    tabla = tabla[["Éxito", "Operando", "Cerrada"]]
    fig, ax = plt.subplots(figsize=(10, 4.8))
    abajo = np.zeros(len(tabla))
    for col in tabla.columns:
        ax.bar(tabla.index.astype(str), tabla[col], bottom=abajo, color=COLORES[col],
               label=col, width=0.65, edgecolor="white", linewidth=2)
        for i, (b, v) in enumerate(zip(abajo, tabla[col])):
            if v >= 4:
                ax.text(i, b + v / 2, f"{v:.0f} %", ha="center", va="center",
                        color="white" if col != "Operando" else TEXTO, fontsize=10)
        abajo += tabla[col].values
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
    ax.set_ylim(0, 100)
    ax.set_xlabel(xlabel)
    ax.set_title(titulo)
    ax.legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.14))
    ax.grid(axis="x", visible=False)
    return fig


def grafico_heatmap(df, filas, columnas, valor, titulo, xlabel="", ylabel="",
                    cmap=SECUENCIAL, min_n=30):
    """Mapa de calor: tasa (%) de `valor` (0/1) para cada combinación filas x columnas.

    Las celdas con menos de `min_n` startups se dejan en blanco (poco fiables).
    """
    tabla = df.pivot_table(index=filas, columns=columnas, values=valor,
                           aggfunc="mean", observed=True) * 100
    n = df.pivot_table(index=filas, columns=columnas, values=valor,
                       aggfunc="size", observed=True)
    tabla = tabla.where(n >= min_n)
    fig, ax = plt.subplots(figsize=(10, 4.5))
    sns.heatmap(tabla, annot=True, fmt=".1f", cmap=cmap, linewidths=2,
                linecolor="white", cbar_kws={"label": "%"}, ax=ax)
    ax.grid(False)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(titulo)
    return fig


def grafico_correlaciones(df, columnas, nombres=None):
    """Matriz de correlación de Spearman (triángulo inferior)."""
    corr = df[columnas].corr(method="spearman")
    if nombres:
        corr = corr.rename(index=nombres, columns=nombres)
    mascara = np.triu(np.ones_like(corr, dtype=bool), k=1)
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(corr, mask=mascara, annot=True, fmt=".2f", cmap="RdBu_r",
                vmin=-1, vmax=1, center=0, linewidths=2, linecolor="white",
                square=True, cbar_kws={"shrink": 0.7}, ax=ax)
    ax.set_title("Matriz de correlación (Spearman)")
    return fig


def grafico_barras_h(serie, titulo, xlabel, color=COLORES["Éxito"], fmt="{:.1f} %"):
    """Barras horizontales ordenadas para rankings (sectores, países...)."""
    serie = serie.sort_values()
    fig, ax = plt.subplots(figsize=(9, 0.42 * len(serie) + 1))
    ax.barh(serie.index.astype(str), serie.values, color=color, height=0.65)
    for i, v in enumerate(serie.values):
        ax.text(v + serie.max() * 0.01, i, fmt.format(v), va="center", color=TEXTO, fontsize=10)
    ax.set_xlim(0, serie.max() * 1.15)
    ax.set_xlabel(xlabel)
    ax.set_title(titulo)
    ax.grid(axis="y", visible=False)
    return fig
