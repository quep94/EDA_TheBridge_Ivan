"""
features.py
-----------
Creación de variables (feature engineering) para el análisis:
resultado de la startup, tramos de financiación, perfil inversor, cohortes...
"""

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Variable objetivo: ¿qué le ha pasado a la startup?
# ---------------------------------------------------------------------------
MAPA_RESULTADO = {
    "operating": "Operando",
    "closed": "Cerrada",
    "acquired": "Éxito",   # adquirida por otra empresa
    "ipo": "Éxito",        # salida a bolsa
}
ORDEN_RESULTADO = ["Éxito", "Operando", "Cerrada"]

# Tramos de financiación total (USD)
TRAMOS_FINANCIACION = [0, 500_000, 2_000_000, 10_000_000, 50_000_000, np.inf]
ETIQUETAS_TRAMOS = ["< 0,5 M$", "0,5–2 M$", "2–10 M$", "10–50 M$", "> 50 M$"]

# Agrupación de los tipos de ronda de Crunchbase
GRUPOS_RONDA = {
    "seed": "semilla_angel",
    "angel": "semilla_angel",
    "venture": "capital_riesgo",
    "private_equity": "capital_riesgo",
    "equity_crowdfunding": "crowdfunding_subvencion",
    "product_crowdfunding": "crowdfunding_subvencion",
    "grant": "crowdfunding_subvencion",
    "non_equity_assistance": "crowdfunding_subvencion",
    "debt_financing": "deuda_otros",
    "convertible_note": "deuda_otros",
    "undisclosed": "deuda_otros",
    "secondary_market": "deuda_otros",
    "post_ipo_equity": "post_ipo",
    "post_ipo_debt": "post_ipo",
}

ORDEN_PERFIL = [
    "Crowdfunding / subvención",
    "Deuda / otros",
    "Solo semilla / ángel",
    "Capital riesgo (VC)",
]

AÑO_MAX_COHORTE_MADURA = 2010  # startups con >= 5 años de recorrido en 2015


def añadir_resultado(df):
    """Añade la variable resultado y dos indicadores binarios.

    - `resultado`: Éxito (adquirida o IPO) / Operando / Cerrada
    - `cerrada`: 1 si la startup ha cerrado (fracaso)
    - `exito`: 1 si ha sido adquirida o ha salido a bolsa
    """
    df = df.copy()
    df["resultado"] = pd.Categorical(
        df["status"].map(MAPA_RESULTADO), categories=ORDEN_RESULTADO, ordered=True
    )
    df["cerrada"] = (df["status"] == "closed").astype(int)
    df["exito"] = df["status"].isin(["acquired", "ipo"]).astype(int)
    return df


def añadir_tramo_financiacion(df, col="funding_total_usd"):
    """Clasifica cada startup en un tramo de financiación total."""
    df = df.copy()
    df["tramo_financiacion"] = pd.cut(
        df[col], bins=TRAMOS_FINANCIACION, labels=ETIQUETAS_TRAMOS, right=False
    )
    df["log10_financiacion"] = np.log10(df[col])
    return df


def _perfil(grupos):
    """Perfil inversor según el tipo de inversión 'más sofisticada' recibida."""
    if "capital_riesgo" in grupos or "post_ipo" in grupos:
        return "Capital riesgo (VC)"
    if "semilla_angel" in grupos:
        return "Solo semilla / ángel"
    if "crowdfunding_subvencion" in grupos:
        return "Crowdfunding / subvención"
    return "Deuda / otros"


def agregar_rondas(rounds):
    """Resume la tabla de rondas a una fila por empresa.

    Devuelve un DataFrame indexado por `company_permalink` con:
      - un indicador por tipo de inversión recibida (tiene_*)
      - `serie_maxima`: última serie de VC alcanzada (A, B, C...)
      - `importe_primera_ronda` y `importe_medio_ronda`
      - `perfil_inversor`
    """
    r = rounds.copy()
    r["grupo"] = r["funding_round_type"].map(GRUPOS_RONDA).fillna("deuda_otros")

    indicadores = (
        pd.crosstab(r["company_permalink"], r["grupo"])
        .clip(upper=1)
        .add_prefix("tiene_")
    )

    # Serie máxima de venture capital (A < B < C ...)
    serie = (
        r.dropna(subset=["funding_round_code"])
        .groupby("company_permalink")["funding_round_code"]
        .max()
        .rename("serie_maxima")
    )

    r_ordenadas = r.sort_values("funded_at")
    importes = r_ordenadas.groupby("company_permalink")["raised_amount_usd"].agg(
        importe_primera_ronda="first", importe_medio_ronda="mean"
    )

    perfil = (
        r.groupby("company_permalink")["grupo"]
        .agg(lambda s: _perfil(set(s)))
        .rename("perfil_inversor")
    )

    return indicadores.join([serie, importes, perfil], how="outer")


def añadir_variables_temporales(df):
    """Variables de tiempo: año de la 1ª ronda, cohorte, duración y edad."""
    df = df.copy()
    df["año_primera_financiacion"] = df["first_funding_at"].dt.year
    df["año_fundacion"] = df["founded_at"].dt.year
    df["cohorte_madura"] = df["año_primera_financiacion"] <= AÑO_MAX_COHORTE_MADURA

    df["años_financiandose"] = (
        (df["last_funding_at"] - df["first_funding_at"]).dt.days / 365.25
    ).round(2)

    edad = (df["first_funding_at"] - df["founded_at"]).dt.days / 365.25
    df["años_hasta_1a_ronda"] = edad.where(edad >= 0).round(2)

    df["cohorte"] = pd.cut(
        df["año_primera_financiacion"],
        bins=[1900, 2005, 2008, 2010, 2012, 2015],
        labels=["≤2005", "2006–08", "2009–10", "2011–12", "2013–15"],
    )
    return df


def agrupar_top(serie, n=10, otros="Otros"):
    """Mantiene las `n` categorías más frecuentes y agrupa el resto en 'Otros'."""
    top = serie.value_counts().head(n).index
    return serie.where(serie.isin(top), otros)


def construir_dataset_analitico(companies, rounds):
    """Une empresas y rondas y crea todas las variables del análisis."""
    df = companies.merge(
        agregar_rondas(rounds), left_on="permalink", right_index=True, how="left"
    )
    df = añadir_resultado(df)
    df = añadir_tramo_financiacion(df)
    df = añadir_variables_temporales(df)

    df["perfil_inversor"] = pd.Categorical(
        df["perfil_inversor"], categories=ORDEN_PERFIL, ordered=True
    )
    df["rondas_grupo"] = pd.cut(
        df["funding_rounds"], bins=[0, 1, 2, 3, 4, np.inf],
        labels=["1", "2", "3", "4", "5+"],
    )
    df["categoria_top"] = agrupar_top(df["main_category"], n=12)
    df["pais_top"] = agrupar_top(df["country_code"], n=8)
    tiene_cols = [c for c in df.columns if c.startswith("tiene_")]
    df[tiene_cols] = df[tiene_cols].fillna(0).astype(int)
    return df
