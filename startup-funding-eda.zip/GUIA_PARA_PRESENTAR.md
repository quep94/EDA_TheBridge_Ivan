# Guía para entender y presentar tu proyecto

> Esta guía es **para ti** (está fuera de la carpeta del repositorio a propósito, para que no se suba a GitHub).
> Léela entera una vez y vuelve a las secciones 4 y 5 antes de presentar.

---

## 1. Qué tienes y para qué sirve cada cosa

```
startup-funding-eda/                 ← ESTA carpeta es el repositorio que subes a GitHub
├── README.md                        ← El "escaparate": de qué va, hallazgos, tecnologías
├── requirements.txt                 ← Librerías necesarias (pip install -r requirements.txt)
├── .gitignore                       ← Archivos que git debe ignorar
├── presentacion/
│   ├── Presentacion_Startups_Financiacion.pptx   ← La presentación (con NOTAS DEL ORADOR)
│   └── Presentacion_Startups_Financiacion.pdf    ← Copia en PDF por si falla PowerPoint
└── src/
    ├── memoria.ipynb                ← LA MEMORIA: todo el análisis explicado paso a paso
    ├── data/raw/                    ← Datos originales de Crunchbase (comprimidos .gz)
    ├── data/processed/              ← Dataset limpio que genera la memoria
    ├── notebooks/
    │   ├── 01_exploracion_inicial.ipynb        ← "Borrador": primer vistazo a los datos
    │   └── 02_pruebas_variables_y_tests.ipynb  ← "Borrador": pruebas de robustez
    ├── utils/                       ← Tu código reutilizable (funciones)
    │   ├── data_cleaning.py         ← Cargar y limpiar
    │   ├── features.py              ← Crear variables nuevas
    │   ├── stats_tests.py           ← Estadísticos y tests de hipótesis
    │   └── plots.py                 ← Gráficos con un estilo común
    └── img/                         ← Todos los gráficos exportados en PNG
```

**Cómo se relacionan:** la `memoria.ipynb` *importa* las funciones de `utils/` (por eso queda limpia y
legible), lee los datos de `data/raw/`, guarda el dataset limpio en `data/processed/` y los gráficos en `img/`.
Los notebooks de `notebooks/` son tus "pruebas", que es justo lo que pide el enunciado.

**Para ejecutar la memoria:** abre una terminal en `src/` y lanza `jupyter notebook memoria.ipynb`
(tiene que ser desde `src/` para que encuentre `utils/` y `data/`). Ya está ejecutada y con los resultados
guardados, así que en GitHub se ve completa sin ejecutar nada.

---

## 2. La historia en 30 segundos (apréndetela)

> Se dice que 9 de cada 10 startups fracasan. Analicé 66.000 startups de Crunchbase para ver si el dinero
> influye. **Sí influye**: las que reciben más de 50 M$ triunfan (son compradas o salen a bolsa) 6 veces más
> y cierran 3 veces menos que las que reciben menos de medio millón. Pero lo más interesante es que **importa
> más cómo llega el dinero que cuánto**: con el mismo dinero, recibirlo en varias rondas reduce el cierre a un
> tercio. Y hay un límite: a partir de 3-4 rondas, más dinero ya no aumenta el éxito.

---

## 3. Entender cada paso técnico (por si te preguntan)

### 3.1 Los datos
- **Crunchbase** es una base de datos mundial de startups. Usamos su **export abierto de 2015** (el actual es de pago).
- **Dos tablas:** `companies` (una fila por empresa: estado, dinero total, país, fechas) y `rounds`
  (una fila por cada ronda de inversión: tipo, importe, fecha). Se **unen** por el identificador `permalink`.

### 3.2 Limpieza: qué hicimos y POR QUÉ (lo más preguntado)
| Qué | Por qué |
|---|---|
| `funding_total_usd` tenía `'-'` → lo pasamos a vacío (NaN) | Era texto; el guion significa "no se sabe". |
| **No** rellenamos los importes vacíos | Es justo la variable que estudiamos: inventarla (con la media, por ejemplo) falsearía el resultado. |
| Fechas imposibles (año 1015, 2914) → vacías | Errores de captura. |
| Quitamos columnas como la web | No aportan al análisis. |
| País/sector vacío → "Unknown" | Para no perder filas. Curiosidad: las "Unknown" cierran muchísimo: las que cierran dejan su ficha a medias. |

### 3.3 Variables que creamos (feature engineering)
- **resultado:** Éxito (comprada o IPO), Operando, Cerrada.
- **exito / cerrada:** columnas de 0 y 1. Truco: **la media de una columna de 0/1 es un porcentaje** → así calculamos tasas.
- **tramo_financiacion:** dividir el dinero en 5 grupos para poder comparar.
- **cohorte_madura:** startups con primera ronda en 2010 o antes.

### 3.4 El sesgo del tiempo (tu punto fuerte, ¡lúcete!)
Una startup financiada en 2014 no ha tenido tiempo de cerrar ni de venderse en 2015. Si las mezclas con las
antiguas, parecería que "les va mejor" (cierran menos) cuando simplemente son jóvenes. Por eso nos quedamos
con las que tienen **≥ 5 años de recorrido** (19.382). En el notebook 02 probamos otros cortes (2008-2012)
y **la conclusión no cambia**: eso se llama **análisis de robustez**.

### 3.5 Conceptos estadísticos explicados en sencillo
| Concepto | Explicación sencilla | Dónde lo usas |
|---|---|---|
| **Media vs mediana** | La mediana es el valor del medio al ordenar. Si Elon Musk entra en un bar, la riqueza *media* se dispara; la *mediana* casi no cambia. | Financiación: media 18 M$, mediana 2 M$ |
| **Asimetría** | Los datos tienen una "cola" larga hacia un lado (pocas empresas con muchísimo dinero). | Por eso usamos escala logarítmica |
| **Escala logarítmica** | Cada salto del eje multiplica por 10 (10 k$ → 100 k$ → 1 M$). Permite ver en el mismo gráfico empresas pequeñas y gigantes. | Histograma y boxplot |
| **Boxplot (diagrama de caja)** | La caja contiene el 50 % central de los datos; la raya de dentro es la mediana. | Dinero por resultado |
| **Intervalo de confianza (IC 95 %)** | Las "rayitas" sobre las barras: el rango donde casi seguro está el valor real. Si dos rayitas no se solapan, la diferencia es fiable. Si hay pocos datos, la rayita es larga. | Gráficos de tasas |
| **p-valor** | Probabilidad de ver una diferencia así *por pura casualidad*. Si es < 0,05 (5 %), decimos que es "estadísticamente significativa". Aquí todas dan < 0,001. | Todos los tests |
| **Chi-cuadrado** | Comprueba si dos variables de categorías (tramo de dinero y resultado) están relacionadas o son independientes. | H1, H2, H3 |
| **V de Cramér** | Dice *cuánto* de fuerte es esa relación, de 0 a 1. Aquí ~0,19 = débil: la relación es real pero el dinero no lo explica todo. | Tamaño del efecto |
| **Mann-Whitney** | Compara dos grupos (éxito vs cerradas) sin suponer que los datos sigan una campana de Gauss. r = 0,44: en ~7 de cada 10 parejas, la de éxito tenía más dinero. | Dinero éxito vs cerrada |
| **Kruskal-Wallis** | Lo mismo que Mann-Whitney pero para 3 o más grupos. | Éxito/Operando/Cerrada |
| **Spearman (correlación)** | De −1 a +1: cuánto se mueven juntas dos variables. +0,26 entre dinero y éxito. | Matriz de correlación |
| **Matriz de correlación** | Tabla de colores que muestra de un vistazo qué variables "van juntas" (rojo) o "en sentido contrario" (azul). | Sección 14 |
| **Test de normalidad** | Comprueba si los datos tienen forma de campana. No la tienen → por eso usamos tests "no paramétricos". | Sección 7 |
| **Correlación ≠ causalidad** | Que dos cosas vayan juntas no significa que una cause la otra. ¿El dinero hace triunfar, o las buenas startups atraen dinero? Probablemente ambas. | Limitaciones |

**¿Cómo explicar una matriz de correlación a alguien no técnico?** (lo pone el enunciado como ejemplo):
> "Es como una tabla de 'amistades' entre variables: si dos suben y bajan a la vez, su casilla es roja; si cuando
> una sube la otra baja, es azul; si no tienen nada que ver, blanca."

---

## 4. Guion de la presentación (≈ 9 minutos, 12 diapositivas)

El **discurso completo de cada diapositiva está en las notas del orador** del PowerPoint
(en PowerPoint: *Vista → Página de notas*, o en modo presentador las verás solo tú).
Cada diapositiva con gráfico tiene abajo una línea **"Cómo leerlo"** que explica qué muestra.

| # | Diapositiva | Tiempo | Mensaje clave |
|---|---|---|---|
| 1 | Portada | 0:30 | Pregunta al público: "¿habéis oído que 9 de cada 10 startups fracasan?" |
| 2 | ¿Cómo consigue dinero una startup? | 0:50 | Contexto: semilla → capital riesgo (Serie A, B, C) → éxito (compra/bolsa) o cierre |
| 3 | 66.367 startups | 0:45 | Crunchbase; los 3 destinos (éxito, operando, cerrada). Pista: solo 9 % cerradas… hay trampa |
| 4 | Hipótesis | 0:50 | Las 5 hipótesis y por qué las pensabas |
| 5 | La trampa del tiempo | 0:45 | Las jóvenes no han tenido tiempo → solo startups con ≥ 5 años |
| 6 | H1 y H2 | 1:10 | ×6 éxito, ÷3 cierre; la típica que triunfa recibió 15,6 M$ vs 4 M$ la que cerró |
| 7 | H3 rondas | 1:00 | **Hallazgo estrella**: mismo dinero, 1 ronda 18,6 % cierran vs 5+ rondas 6,7 % |
| 8 | H4 más no es mejor | 0:50 | El éxito toca techo en 3-4 rondas: hipótesis refutada |
| 9 | H5 país | 0:45 | EE. UU. lidera, pero el efecto del dinero se repite fuera |
| 10 | ¿Acerté? | 0:25 | 4 de 5. Señala solo la H4 |
| 11 | Conclusiones | 1:00 | Fundadores / inversores / fuera de EE. UU. + límite (relación ≠ causa) |
| 12 | Gracias | 0:15 | Frase final y preguntas |

Total ≈ 9:05 → te deja ~1 minuto de margen.

**Vocabulario que aparece en las diapositivas:**
- **Startup:** empresa joven que quiere crecer muy rápido; al principio vive del dinero de inversores.
- **Ronda de financiación:** cada vez que recibe dinero a cambio de una parte de la empresa.
- **Semilla / business angel:** primeras inversiones pequeñas, de fundadores, familia o particulares.
- **Capital riesgo (Serie A, B, C…):** fondos profesionales que invierten millones; cada letra es una ronda más avanzada.
- **Salida / éxito:** cuando otra empresa la compra o sale a bolsa; es cuando los inversores recuperan su dinero.
- **M$:** millones de dólares.
- **Mapa de calor:** tabla en la que el color indica el valor (más oscuro = más alto).

**Consejos:**
- No leas las diapositivas: cuenta la historia. Cada título es la frase que tienes que decir.
- Cuando muestres un gráfico, di primero **qué representa** (usa la línea "Cómo leerlo") y luego **el dato**.
- Si tienes relación con el mundo startup/emprendimiento, cuéntalo en la portada: conecta con el público.
- **Antes de presentar:** añade tu nombre en la portada (diapositiva 1, debajo de "Proyecto Data Analysis").

---

## 5. Preguntas difíciles que te pueden hacer

| Pregunta | Respuesta |
|---|---|
| ¿El dinero causa el éxito? | No puedo demostrarlo: es una relación, no una causa. Pero el dato de las rondas (mismo dinero, menos cierres con más rondas) apunta a que el "cómo" importa por sí mismo. |
| ¿Por qué datos de 2015? | Es el último export abierto de Crunchbase. Y precisamente al ser antiguo, da tiempo a ver qué pasó con las startups. |
| ¿Por qué no rellenaste los importes que faltaban? | Porque es la variable que estudio; rellenarla con la media inventaría datos y sesgaría la conclusión. |
| ¿Qué pasa con las "Operando"? | No cuentan como éxito ni como fracaso: aún no tienen desenlace. Algunas serán "zombis". |
| ¿Son significativas las diferencias? | Sí, todos los tests dan p < 0,001. Pero el tamaño del efecto es débil-moderado: el dinero es uno de muchos factores (equipo, mercado, momento…). |
| ¿Por qué usaste la mediana? | Porque la financiación está muy sesgada: unas pocas empresas con miles de millones disparan la media. |
| ¿Por qué tests no paramétricos? | Porque los datos no son normales (lo comprobé con un test de normalidad). |
| ¿Y España? | 746 startups, mediana 0,64 M$ (tres veces menos que la global), 4,8 % de éxito; pero son muy jóvenes: solo 165 tienen 5+ años. |
| ¿Por qué el corte en 2010? | Para que todas tengan ≥ 5 años. Probé de 2008 a 2012 y el patrón se repite siempre. |
| ¿Qué harías después? | Un modelo predictivo (regresión logística) que estime la probabilidad de éxito controlando por país, sector y año a la vez; y repetirlo con datos actuales de España. |

---

## 6. Cómo subirlo a GitHub

1. Crea un repositorio **vacío** en GitHub (sin README) llamado, por ejemplo, `startup-funding-eda`.
2. En una terminal, dentro de la carpeta `startup-funding-eda`:

```bash
git init
```

```bash
git add .
```

```bash
git commit -m "EDA: influencia de la financiación en la supervivencia y el éxito de startups"
```

```bash
git branch -M main
```

```bash
git remote add origin https://github.com/TU_USUARIO/startup-funding-eda.git
```

```bash
git push -u origin main
```

3. Sube el enlace del repositorio al Campus Virtual.

Los archivos de datos pesan entre 3 y 5 MB cada uno (comprimidos), muy por debajo del límite de GitHub (100 MB).

---

## 7. Checklist antes de entregar

- [ ] Tu nombre en la portada de la presentación
- [ ] Abrir `memoria.ipynb` en GitHub y comprobar que se ven los gráficos
- [ ] Ensayar la presentación cronometrando (objetivo: 9-10 min)
- [ ] Llevar el PDF de la presentación en un USB por si falla algo
- [ ] Repasar la sección 5 de esta guía
